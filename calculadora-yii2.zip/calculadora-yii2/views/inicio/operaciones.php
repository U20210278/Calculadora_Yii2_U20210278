<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\inicioForm;
$model = new inicioForm();
?>

<?php
if (isset($respuesta)) {
    echo Html::tag('div', Html::encode($respuesta), ['class' => 'alert alert-warning']);
}
?>

<div class="row">
    <div class="container">
        <?php $formulario = ActiveForm::begin(); ?>

        <?= $formulario->field($model, 'opcion[]')->checkboxList(['0' => 'suma', '1' => 'resta', '2' => 'multiplicacion', '3' => 'division']); ?>
        <?= $formulario->field($model, 'valor_a') ?>
        <?= $formulario->field($model, 'valor_b') ?>

        <div class="form-group">
            <?= Html::submitButton('Aceptar', ['class' => 'btn btn-success']) ?>
        </div>

        <?php ActiveForm::end(); ?>
    </div>
</div>