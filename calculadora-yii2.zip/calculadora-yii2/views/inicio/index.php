<div class="site-index">
    <div class="jumbotron">
        <h1><?= $mensaje ?></h1>
        <h2><?= $h2 ?></h2>
        <h2><?= date_format($dateTime, 'Y-m-d H:i:s'); ?></h2>
    </div>
</div>