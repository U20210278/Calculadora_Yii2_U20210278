<?php



use yii\widgets\ActiveForm;
use yii\helpers\Html;

?>

<div class= "row">
    <div class ="container">
    <h1>CALCULADORA</h1>
    <?php $formulario = ActionForm ::begin(); ?>
    <div class="row">
        <div class="col-6">
            <?= $formulario->field($model, 'valor_a')?>            
        </div>
        <div class="col-6">
            <?= $formulario->field($model, 'valor_b')?>            
        </div>
    </div>
    <div class="btn-group">
        <?= $formulario->field($model, 'operacion')->radioList([0=>'+ Suma',1=>'- Resta',2=>'x Multiplicacion',3=>'/ Division'],['unselect'=>null])
        ?>;
    </div>
    <hr>
    <div class="form-group">
        <div class="row">
            <div class="col-1">
                <?= Html:: submitButton('Calcular',['class'=> 'btn btn-primary']);?>
            </div>
            <div class="col-11">
                <?php
                if(isset($respuesta))
                {
                    echo Html::tag('div',Html::encode($respuesta),['class'=>'alert alert-info']);
                }
                ?>
            </div>
        </div>
    </div>
    
    <?php ActiveForm:: end();?>


    </div>



</div>