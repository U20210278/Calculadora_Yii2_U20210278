<?php
namespace app\models;
 
use yii;
use yii\base\Model;

class CalculadoraModel extends Model
{
    public $valor_a;
    public $valor_b;
    public $operacion;


    public function rules(){
        return[
            [['valor_a','valor_b','operacion'],'required'],
            [['valor_a','valor_b'],'number']
        ];
    }


}



?>